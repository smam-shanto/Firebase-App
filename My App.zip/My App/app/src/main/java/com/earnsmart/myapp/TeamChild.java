package com.earnsmart.myapp;

public class TeamChild {
    String name, position, refer, rank, parent;

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public String getRefer() {
        return refer;
    }

    public String getRank() {
        return rank;
    }

    public String getParent() {
        return parent;
    }
}
