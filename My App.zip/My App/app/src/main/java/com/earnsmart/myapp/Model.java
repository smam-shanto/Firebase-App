package com.earnsmart.myapp;

public class Model {
    private String header;
    private int imgname;
    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }


    public int getImgname() {
        return imgname;
    }

    public void setImgname(int imgname) {
        this.imgname = imgname;
    }
}
